package cn.zucc.debug.frame.ssm;

/**
 * @author GongTengPangYi
 */
public class BaseController {
}
