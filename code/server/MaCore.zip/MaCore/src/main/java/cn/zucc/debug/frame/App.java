package cn.zucc.debug.frame;

/**
 * @author GongTengPangYi
 */
public class App {
}
